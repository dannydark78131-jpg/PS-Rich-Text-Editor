@echo off
rem Build a proper Setup.exe using Inno Setup (install from jrsoftware.org).
rem Run this in the folder containing installer.iss + the app files.
setlocal
set "ISCC="
for %%P in (
  "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
  "%ProgramFiles%\Inno Setup 6\ISCC.exe"
  "%ProgramFiles(x86)%\Inno Setup 5\ISCC.exe"
  "%ProgramFiles%\Inno Setup 5\ISCC.exe"
) do if exist "%%~P" set "ISCC=%%~P"

if "%ISCC%"=="" (
  echo Inno Setup was not found. Install Inno Setup 6 from jrsoftware.org,
  echo then re-run this script.
  pause
  exit /b 1
)

"%ISCC%" "%~dp0installer.iss"
if errorlevel 1 (
  echo.
  echo Build failed. See messages above.
  pause
  exit /b 1
)
echo.
echo Built: %~dp0dist\PSRichTextEditor-Setup-1.0.0.exe
pause
endlocal
