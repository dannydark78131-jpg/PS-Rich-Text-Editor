#Requires -Version 5.1
<#
.SYNOPSIS
    One-click installer for PS Rich Text Editor (per-user, no admin).
.DESCRIPTION
    Copies RichTextEditor.ps1 + RichTextEditor.ico + Uninstall.ps1 to
    %LOCALAPPDATA%\Programs\PSRichTextEditor, creates Start Menu and Desktop
    shortcuts (.lnk) with the app icon, and registers an Add/Remove Programs
    entry (HKCU) so the app can be uninstalled from Settings.
#>
$ErrorActionPreference = "Stop"

$appName     = "PS Rich Text Editor"
$appId       = "PSRichTextEditor"
$version     = "1.0.0"
$srcDir      = $PSScriptRoot
$installDir  = Join-Path $env:LOCALAPPDATA "Programs\$appId"
$startMenu   = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\$appName"
$desktopLnk  = Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) "$appName.lnk"
$psExe       = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"

function Write-Step { param([string]$Msg) Write-Host "==> $Msg" -ForegroundColor Cyan }

# --- Verify source files are next to this installer ---
$need = @('RichTextEditor.ps1', 'RichTextEditor.ico', 'Uninstall.ps1')
foreach ($f in $need) {
    $p = Join-Path $srcDir $f
    if (-not (Test-Path -LiteralPath $p)) {
        Write-Host "ERROR: required file not found: $f" -ForegroundColor Red
        Write-Host "Place Install.bat / Install.ps1 in the same folder as $($need -join ', ')." -ForegroundColor Yellow
        exit 1
    }
}

# --- Copy files ---
Write-Step "Installing to $installDir"
if (-not (Test-Path -LiteralPath $installDir)) {
    New-Item -ItemType Directory -Path $installDir -Force | Out-Null
}
foreach ($f in $need) {
    Copy-Item -LiteralPath (Join-Path $srcDir $f) -Destination (Join-Path $installDir $f) -Force
}
$installedScript = Join-Path $installDir 'RichTextEditor.ps1'
$installedIcon   = Join-Path $installDir 'RichTextEditor.ico'

# --- Shortcuts ---
function New-Shortcut {
    param([string]$LnkPath, [string]$Arguments)
    $dir = Split-Path -LiteralPath $LnkPath -Parent
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $shell = New-Object -ComObject WScript.Shell
    $lnk = $shell.CreateShortcut($LnkPath)
    $lnk.TargetPath       = $psExe
    $lnk.Arguments        = $Arguments
    $lnk.WorkingDirectory = $installDir
    $lnk.IconLocation     = '{0},0' -f $installedIcon
    $lnk.Description      = $appName
    $lnk.Save()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($shell) | Out-Null
}

$args = '-NoProfile -STA -ExecutionPolicy Bypass -File "{0}"' -f $installedScript
Write-Step "Creating Start Menu shortcut"
New-Shortcut -LnkPath (Join-Path $startMenu "$appName.lnk") -Arguments $args
Write-Step "Creating Desktop shortcut"
New-Shortcut -LnkPath $desktopLnk -Arguments $args

# --- Add/Remove Programs entry (HKCU, no admin) ---
Write-Step "Registering uninstall entry"
$uninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$appId"
if (-not (Test-Path -LiteralPath $uninstallKey)) { New-Item -Path $uninstallKey -Force | Out-Null }
$uninstallCmd = '"{0}" -NoProfile -ExecutionPolicy Bypass -File "{1}"' -f $psExe, (Join-Path $installDir 'Uninstall.ps1')
Set-ItemProperty -LiteralPath $uninstallKey -Name DisplayName     -Value $appName
Set-ItemProperty -LiteralPath $uninstallKey -Name DisplayVersion  -Value $version
Set-ItemProperty -LiteralPath $uninstallKey -Name Publisher       -Value 'PS Rich Text Editor'
Set-ItemProperty -LiteralPath $uninstallKey -Name InstallLocation -Value $installDir
Set-ItemProperty -LiteralPath $uninstallKey -Name DisplayIcon     -Value $installedIcon
Set-ItemProperty -LiteralPath $uninstallKey -Name UninstallString -Value $uninstallCmd
Set-ItemProperty -LiteralPath $uninstallKey -Name NoModify        -Value 1 -Type DWord
Set-ItemProperty -LiteralPath $uninstallKey -Name NoRepair        -Value 1 -Type DWord

Write-Host ""
Write-Host "Installed successfully!" -ForegroundColor Green
Write-Host "  Location : $installDir"
Write-Host "  Start    : $appName (Start Menu)"
Write-Host "  Desktop  : $desktopLnk"
Write-Host "  Uninstall: Settings > Apps > $appName"
Write-Host ""

$r = Read-Host "Launch $appName now? [Y/n] (default Y)"
if ($r -notmatch '^[Nn]') {
    Start-Process -FilePath $psExe -ArgumentList $args
}
exit 0
