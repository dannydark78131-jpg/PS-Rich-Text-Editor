; Inno Setup script for PS Rich Text Editor.
; Build:  build_installer.bat  (requires Inno Setup 6 from jrsoftware.org)
; Produces: dist\PSRichTextEditor-Setup-1.0.0.exe  (per-user install, no admin)

#define MyAppName      "PS Rich Text Editor"
#define MyAppVersion   "1.0.0"
#define MyAppExeName   "RichTextEditor.ps1"

[Setup]
AppId={{691d365c-5c84-4f55-9a7e-d4b5ef700c03}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppName}
DefaultDirName={localappdata}\Programs\PSRichTextEditor
DefaultGroupName={#MyAppName}
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=dist
OutputBaseFilename=PSRichTextEditor-Setup-{#MyAppVersion}
UninstallDisplayIcon={app}\RichTextEditor.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
DisableProgramGroupPage=yes

[Files]
Source: "RichTextEditor.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "RichTextEditor.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "Uninstall.ps1";     DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -STA -ExecutionPolicy Bypass -File ""{app}\{#MyAppExeName}"""; WorkingDir: "{app}"; IconFilename: "{app}\RichTextEditor.ico"
Name: "{userdesktop}\{#MyAppName}"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -STA -ExecutionPolicy Bypass -File ""{app}\{#MyAppExeName}"""; WorkingDir: "{app}"; IconFilename: "{app}\RichTextEditor.ico"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Run]
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -STA -ExecutionPolicy Bypass -File ""{app}\{#MyAppExeName}"""; Description: "Launch {#MyAppName} now"; Flags: nowait postinstall skipifsilent
