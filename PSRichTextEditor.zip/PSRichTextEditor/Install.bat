@echo off
rem One-click installer launcher for PS Rich Text Editor.
rem Double-click this file (no admin required - installs per-user).
setlocal
chcp 65001 >nul
powershell -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
echo.
echo Installation finished. Press any key to close this window.
pause >nul
endlocal
