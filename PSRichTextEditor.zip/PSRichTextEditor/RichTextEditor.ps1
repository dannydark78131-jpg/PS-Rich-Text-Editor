#Requires -Version 5.1
<#
.SYNOPSIS
    Rich Text Reader & Editor (WinForms, single-file PowerShell).
.DESCRIPTION
    Self-contained RTF/TXT editor with toolbar formatting, a Settings dialog
    that can install the app, create/refresh a desktop shortcut (.lnk), and
    tint the shortcut's icon with a chosen colour.
.PARAMETER File
    Optional document (.rtf or .txt) to open on launch.
.NOTES
    Run:  powershell -NoProfile -STA -ExecutionPolicy Bypass -File RichTextEditor.ps1
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$File
)

$ErrorActionPreference = "Stop"

# --- WinForms needs STA; re-launch under STA if the host is MTA (e.g. console) ---
if ($host.Runspace.ApartmentState -ne 'STA') {
    $argList = [System.Collections.ArrayList]@('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath)
    if ($File) { [void]$argList.Add($File) }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $argList.ToArray()
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------------------------------------------------------------------------
# Shared state
# ---------------------------------------------------------------------------
$script:appName      = "PS Rich Text Editor"
$script:appDataDir   = Join-Path $env:LOCALAPPDATA 'PSRichTextEditor'
$script:currentFile  = $null        # full path of open document
$script:modified     = $false
$script:shortcutColor = [System.Drawing.Color]::FromArgb(0x25, 0x63, 0xEB)  # default blue
$script:installPath  = Join-Path $env:LOCALAPPDATA 'Programs\PSRichTextEditor'
$script:swatches     = @(
    [System.Drawing.Color]::FromArgb(0x25, 0x63, 0xEB),  # Blue
    [System.Drawing.Color]::FromArgb(0x0D, 0x94, 0x88),  # Teal
    [System.Drawing.Color]::FromArgb(0x16, 0xA3, 0x4A),  # Green
    [System.Drawing.Color]::FromArgb(0xEA, 0x58, 0x0C),  # Orange
    [System.Drawing.Color]::FromArgb(0xDC, 0x26, 0x26),  # Red
    [System.Drawing.Color]::FromArgb(0x93, 0x33, 0xEA),  # Purple
    [System.Drawing.Color]::FromArgb(0xDB, 0x27, 0x77),  # Pink
    [System.Drawing.Color]::FromArgb(0x4B, 0x55, 0x63)   # Slate
)

if (-not (Test-Path -LiteralPath $script:appDataDir)) {
    New-Item -ItemType Directory -Path $script:appDataDir -Force | Out-Null
}

# ---------------------------------------------------------------------------
# Settings persistence (simple key=value file)
# ---------------------------------------------------------------------------
function Import-AppSettings {
    $cfg = Join-Path $script:appDataDir 'settings.ini'
    if (-not (Test-Path -LiteralPath $cfg)) { return }
    foreach ($line in Get-Content -LiteralPath $cfg -Encoding UTF8) {
        if ($line -match '^\s*([^=]+?)\s*=\s*(.*?)\s*$') {
            $k = $matches[1].Trim(); $v = $matches[2].Trim()
            switch ($k) {
                'InstallPath'   { if ($v) { $script:installPath = $v } }
                'ShortcutColor' {
                    if ($v -match '^[0-9A-Fa-f]{6}$') {
                        $script:shortcutColor = [System.Drawing.Color]::FromArgb(
                            [Convert]::ToInt32($v.Substring(0,2),16),
                            [Convert]::ToInt32($v.Substring(2,2),16),
                            [Convert]::ToInt32($v.Substring(4,2),16))
                    }
                }
            }
        }
    }
}

function Export-AppSettings {
    $cfg = Join-Path $script:appDataDir 'settings.ini'
    $c = $script:shortcutColor
    $hex = '{0:X2}{1:X2}{2:X2}' -f $c.R, $c.G, $c.B
    @(
        "InstallPath=$($script:installPath)",
        "ShortcutColor=$hex"
    ) | Set-Content -LiteralPath $cfg -Encoding UTF8
}

# ---------------------------------------------------------------------------
# Icon generation (self-contained: draws a stylish rounded-square icon and
# writes a multi-size, PNG-compressed .ico so no external image is needed)
# ---------------------------------------------------------------------------
function Get-Shade {
    param([System.Drawing.Color]$Base, [int]$Delta)
    $r = [Math]::Max(0, [Math]::Min(255, $Base.R + $Delta))
    $g = [Math]::Max(0, [Math]::Min(255, $Base.G + $Delta))
    $b = [Math]::Max(0, [Math]::Min(255, $Base.B + $Delta))
    return [System.Drawing.Color]::FromArgb($r, $g, $b)
}

function New-IconBitmap {
    param([int]$Size, [System.Drawing.Color]$BaseColor)

    $bmp = New-Object System.Drawing.Bitmap($Size, $Size)
    $g   = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode     = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode   = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $g.Clear([System.Drawing.Color]::Transparent)

    # Rounded-square background with a vertical gradient (light -> base)
    $radius = [Math]::Max(2, [int]($Size * 0.22))
    $d = $radius * 2
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc(0, 0, $d, $d, 180, 90)
    $path.AddArc(($Size - $d), 0, $d, $d, 270, 90)
    $path.AddArc(($Size - $d), ($Size - $d), $d, $d, 0, 90)
    $path.AddArc(0, ($Size - $d), $d, $d, 90, 90)
    $path.CloseFigure()

    $rect = New-Object System.Drawing.RectangleF(0, 0, $Size, $Size)
    $top = Get-Shade $BaseColor 55
    $bot = Get-Shade $BaseColor -25
    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $top, $bot, 90)
    $g.FillPath($brush, $path)
    $brush.Dispose()

    # Subtle inner highlight at the top
    if ($Size -ge 32) {
        $hiRect = New-Object System.Drawing.RectangleF(($Size*0.12), ($Size*0.06), ($Size*0.76), ($Size*0.30))
        $hiBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(40, 255, 255, 255))
        $hiPath = New-Object System.Drawing.Drawing2D.GraphicsPath
        $hr = $radius * 0.6
        $hd = $hr * 2
        $hiPath.AddArc(($Size*0.12), ($Size*0.06), $hd, $hd, 180, 90)
        $hiPath.AddArc(($Size*0.88 - $hd), ($Size*0.06), $hd, $hd, 270, 90)
        $hiPath.AddArc(($Size*0.88 - $hd), ($Size*0.36 - $hd), $hd, $hd, 0, 90)
        $hiPath.AddArc(($Size*0.12), ($Size*0.36 - $hd), $hd, $hd, 90, 90)
        $hiPath.CloseFigure()
        $g.FillPath($hiBrush, $hiPath)
        $hiBrush.Dispose(); $hiPath.Dispose()
    }

    # White "R" glyph, centred, with a soft drop shadow on larger sizes
    $emSize = [Math]::Max(6, [float]($Size * 0.52))
    $font   = New-Object System.Drawing.Font('Segoe UI', $emSize, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
    $fmt    = New-Object System.Drawing.StringFormat
    $fmt.Alignment     = [System.Drawing.StringAlignment]::Center
    $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
    $textRect = New-Object System.Drawing.RectangleF(0, (-$Size*0.04), $Size, $Size)

    if ($Size -ge 32) {
        $shadowBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(90, 0, 0, 0))
        $off = [Math]::Max(1, [int]($Size * 0.02))
        $shadowRect = New-Object System.Drawing.RectangleF($off, (-$Size*0.04 + $off), $Size, $Size)
        $g.DrawString('R', $font, $shadowBrush, $shadowRect, $fmt)
        $shadowBrush.Dispose()
    }
    $whiteBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    $g.DrawString('R', $font, $whiteBrush, $textRect, $fmt)
    $whiteBrush.Dispose()

    # Accent bar at the bottom (like an underline / text cursor)
    if ($Size -ge 24) {
        $barW = [int]($Size * 0.42)
        $barH = [Math]::Max(2, [int]($Size * 0.07))
        $barX = [int](($Size - $barW) / 2)
        $barY = [int]($Size * 0.76)
        $barRect = New-Object System.Drawing.Rectangle($barX, $barY, $barW, $barH)
        $barPath = New-Object System.Drawing.Drawing2D.GraphicsPath
        $br = [int]($barH / 2); $bd = $br * 2
        $barPath.AddArc($barX, $barY, $bd, $bd, 180, 90)
        $barPath.AddArc(($barX + $barW - $bd), $barY, $bd, $bd, 270, 90)
        $barPath.AddArc(($barX + $barW - $bd), ($barY + $barH - $bd), $bd, $bd, 0, 90)
        $barPath.AddArc($barX, ($barY + $barH - $bd), $bd, $bd, 90, 90)
        $barPath.CloseFigure()
        $barBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(230, 255, 255, 255))
        $g.FillPath($barBrush, $barPath)
        $barBrush.Dispose(); $barPath.Dispose()
    }

    $font.Dispose(); $fmt.Dispose(); $path.Dispose(); $g.Dispose()
    return $bmp
}

function Save-IconFile {
    param([System.Drawing.Color]$BaseColor, [string]$Path)
    $sizes = @(16, 32, 48, 256)
    $bitmaps = @()
    foreach ($s in $sizes) { $bitmaps += ,(New-IconBitmap -Size $s -BaseColor $BaseColor) }

    $ms = New-Object System.IO.MemoryStream
    $bw = New-Object System.IO.BinaryWriter($ms)
    $bw.Write([UInt16]0)                       # reserved
    $bw.Write([UInt16]1)                       # type = icon
    $bw.Write([UInt16]$bitmaps.Count)          # count

    $pngBlobs = New-Object System.Collections.Generic.List[byte[]]
    $offset = 6 + (16 * $bitmaps.Count)
    foreach ($bmp in $bitmaps) {
        $png = New-Object System.IO.MemoryStream
        $bmp.Save($png, [System.Drawing.Imaging.ImageFormat]::Png)
        $bytes = $png.ToArray()
        $png.Dispose()
        $w = if ($bmp.Width  -ge 256) { 0 } else { $bmp.Width }
        $h = if ($bmp.Height -ge 256) { 0 } else { $bmp.Height }
        $bmp.Dispose()
        $pngBlobs.Add($bytes)
        $bw.Write([Byte]$w)
        $bw.Write([Byte]$h)
        $bw.Write([Byte]0)                     # palette count
        $bw.Write([Byte]0)                     # reserved
        $bw.Write([UInt16]1)                   # planes
        $bw.Write([UInt16]32)                  # bit count
        $bw.Write([UInt32]$bytes.Length)       # bytes in resource
        $bw.Write([UInt32]$offset)             # image offset
        $offset += $bytes.Length
    }
    foreach ($bytes in $pngBlobs) { $bw.Write($bytes) }
    $bw.Flush()
    [System.IO.File]::WriteAllBytes($Path, $ms.ToArray())
    $bw.Dispose(); $ms.Dispose()
}

function Get-DefaultIconPath {
    $ico = Join-Path $script:appDataDir 'app.ico'
    if (-not (Test-Path -LiteralPath $ico)) {
        Save-IconFile -BaseColor $script:shortcutColor -Path $ico
    }
    return $ico
}

function Get-ShortcutIconPath {
    $ico = Join-Path $script:appDataDir 'shortcut.ico'
    Save-IconFile -BaseColor $script:shortcutColor -Path $ico
    return $ico
}

# ---------------------------------------------------------------------------
# Shortcut (.lnk) helpers
# ---------------------------------------------------------------------------
function Get-DesktopShortcutPath {
    return Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) 'PS Rich Text Editor.lnk'
}

function Get-TargetScriptPath {
    # Prefer the installed copy; fall back to this running script.
    $installed = Join-Path $script:installPath 'RichTextEditor.ps1'
    if (Test-Path -LiteralPath $installed) { return $installed }
    return $PSCommandPath
}

function New-DesktopShortcut {
    $icoPath = Get-ShortcutIconPath
    $scriptPath = Get-TargetScriptPath
    $lnkPath = Get-DesktopShortcutPath
    $shell = New-Object -ComObject WScript.Shell
    $lnk = $shell.CreateShortcut($lnkPath)
    $lnk.TargetPath       = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $lnk.Arguments        = '-NoProfile -STA -ExecutionPolicy Bypass -File "{0}"' -f $scriptPath
    $lnk.WorkingDirectory = Split-Path -LiteralPath $scriptPath -Parent
    $lnk.IconLocation     = '{0},0' -f $icoPath
    $lnk.Description      = $script:appName
    $lnk.Save()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($shell) | Out-Null
    return $lnkPath
}

function Remove-DesktopShortcut {
    $lnkPath = Get-DesktopShortcutPath
    if (Test-Path -LiteralPath $lnkPath) { Remove-Item -LiteralPath $lnkPath -Force }
}

function Install-App {
    param([switch]$CreateDesktopShortcut)
    if (-not (Test-Path -LiteralPath $script:installPath)) {
        New-Item -ItemType Directory -Path $script:installPath -Force | Out-Null
    }
    Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $script:installPath 'RichTextEditor.ps1') -Force
    Save-IconFile -BaseColor $script:shortcutColor -Path (Join-Path $script:installPath 'app.ico')

    # Start Menu shortcut
    $startDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\PS Rich Text Editor'
    if (-not (Test-Path -LiteralPath $startDir)) { New-Item -ItemType Directory -Path $startDir -Force | Out-Null }
    $shell = New-Object -ComObject WScript.Shell
    $lnk = $shell.CreateShortcut((Join-Path $startDir 'PS Rich Text Editor.lnk'))
    $lnk.TargetPath       = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $lnk.Arguments        = '-NoProfile -STA -ExecutionPolicy Bypass -File "{0}"' -f (Join-Path $script:installPath 'RichTextEditor.ps1')
    $lnk.WorkingDirectory = $script:installPath
    $lnk.IconLocation     = '{0},0' -f (Join-Path $script:installPath 'app.ico')
    $lnk.Description      = $script:appName
    $lnk.Save()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($shell) | Out-Null

    if ($CreateDesktopShortcut) { [void](New-DesktopShortcut) }
}

# ---------------------------------------------------------------------------
# Document helpers
# ---------------------------------------------------------------------------
function Get-StreamType {
    param([string]$Path)
    if ($Path -match '\.txt$') { return [System.Windows.Forms.RichTextBoxStreamType]::PlainText }
    return [System.Windows.Forms.RichTextBoxStreamType]::RichText
}

function Set-Title {
    $name = if ($script:currentFile) { Split-Path -LiteralPath $script:currentFile -Leaf } else { 'Untitled' }
    $star = if ($script:modified) { ' *' } else { '' }
    $mainForm.Text = '{0} - {1}{2}' -f $script:appName, $name, $star
}

function Confirm-SaveIfModified {
    if (-not $script:modified) { return $true }
    $r = [System.Windows.Forms.MessageBox]::Show(
        'Save changes to the current document?', $script:appName,
        [System.Windows.Forms.MessageBoxButtons]::YesNoCancel,
        [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($r -eq [System.Windows.Forms.DialogResult]::Cancel) { return $false }
    if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { Save-Document; return (-not $script:modified) }
    return $true
}

function Open-Document {
    param([string]$Path)
    if (-not (Confirm-SaveIfModified)) { return }
    try {
        $rtb.LoadFile($Path, (Get-StreamType $Path))
        $script:currentFile = $Path
        $script:modified = $false
        Set-Title
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not open file:`n$_", $script:appName, 'OK', 'Error') | Out-Null
    }
}

function Save-Document {
    if (-not $script:currentFile) { [void](Save-DocumentAs); return }
    try {
        $rtb.SaveFile($script:currentFile, (Get-StreamType $script:currentFile))
        $script:modified = $false
        Set-Title
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not save file:`n$_", $script:appName, 'OK', 'Error') | Out-Null
    }
}

function Save-DocumentAs {
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter   = 'Rich Text (*.rtf)|*.rtf|Plain Text (*.txt)|*.txt|All files (*.*)|*.*'
    $dlg.Title    = 'Save document as'
    $dlg.AddExtension = $true
    if ($script:currentFile) {
        $dlg.InitialDirectory = Split-Path -LiteralPath $script:currentFile -Parent
        $dlg.FileName = [IO.Path]::GetFileNameWithoutExtension($script:currentFile)
    }
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $script:currentFile = $dlg.FileName
        Save-Document
    }
    $dlg.Dispose()
}

function New-Document {
    if (-not (Confirm-SaveIfModified)) { return }
    $rtb.Clear()
    $script:currentFile = $null
    $script:modified = $false
    Set-Title
}

# ---------------------------------------------------------------------------
# Settings dialog
# ---------------------------------------------------------------------------
function Show-SettingsDialog {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Settings'
    $dlg.Width = 460; $dlg.Height = 430
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.StartPosition = 'CenterParent'
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI', 9)

    $y = 12

    # --- Install group ---
    $grpInstall = New-Object System.Windows.Forms.GroupBox
    $grpInstall.Text = ' Installation '
    $grpInstall.Location = '12,10'
    $grpInstall.Size = '420,110'
    $dlg.Controls.Add($grpInstall)

    $lblPath = New-Object System.Windows.Forms.Label
    $lblPath.Text = 'Install location:'
    $lblPath.Location = '12,28'; $lblPath.Size = '100,20'
    $grpInstall.Controls.Add($lblPath)

    $txtPath = New-Object System.Windows.Forms.TextBox
    $txtPath.Location = '12,50'; $txtPath.Size = '300,22'
    $txtPath.Text = $script:installPath
    $grpInstall.Controls.Add($txtPath)

    $btnBrowse = New-Object System.Windows.Forms.Button
    $btnBrowse.Text = 'Browse...'
    $btnBrowse.Location = '318,49'; $btnBrowse.Size = '85,24'
    $btnBrowse.Add_Click({
        $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
        $fbd.Description = 'Choose install folder'
        if ($txtPath.Text -and (Test-Path -LiteralPath $txtPath.Text)) { $fbd.SelectedPath = $txtPath.Text }
        if ($fbd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $txtPath.Text = $fbd.SelectedPath }
        $fbd.Dispose()
    })
    $grpInstall.Controls.Add($btnBrowse)

    $chkDesktop = New-Object System.Windows.Forms.CheckBox
    $chkDesktop.Text = 'Also create a desktop shortcut'
    $chkDesktop.Location = '12,78'; $chkDesktop.Size = '260,20'
    $chkDesktop.Checked = $true
    $grpInstall.Controls.Add($chkDesktop)

    $btnInstall = New-Object System.Windows.Forms.Button
    $btnInstall.Text = 'Install'
    $btnInstall.Location = '318,76'; $btnInstall.Size = '85,24'
    $btnInstall.Add_Click({
        $script:installPath = $txtPath.Text.Trim()
        if (-not $script:installPath) {
            [System.Windows.Forms.MessageBox]::Show('Please choose an install location.', $script:appName, 'OK', 'Warning') | Out-Null
            return
        }
        try {
            Install-App -CreateDesktopShortcut:($chkDesktop.Checked)
            [System.Windows.Forms.MessageBox]::Show("Installed to:`n$($script:installPath)", $script:appName, 'OK', 'Information') | Out-Null
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Install failed:`n$_", $script:appName, 'OK', 'Error') | Out-Null
        }
    })
    $grpInstall.Controls.Add($btnInstall)

    # --- Shortcut colour group ---
    $grpColour = New-Object System.Windows.Forms.GroupBox
    $grpColour.Text = ' Desktop shortcut (.lnk) icon colour '
    $grpColour.Location = '12,126'
    $grpColour.Size = '420,150'
    $dlg.Controls.Add($grpColour)

    $lblNote = New-Object System.Windows.Forms.Label
    $lblNote.Text = "Windows cannot colour a shortcut's text per-file. Click a swatch to tint the .lnk icon and refresh the desktop shortcut."
    $lblNote.Location = '12,25'; $lblNote.Size = '390,32'
    $lblNote.ForeColor = [System.Drawing.Color]::FromArgb(0x6B, 0x72, 0x80)
    $grpColour.Controls.Add($lblNote)

    # Swatch buttons
    $swX = 12; $swY = 62; $swSize = 30; $gap = 8
    foreach ($col in $script:swatches) {
        $btn = New-Object System.Windows.Forms.Button
        $btn.Size = "$swSize,$swSize"
        $btn.Location = "$swX,$swY"
        $btn.BackColor = $col
        $btn.FlatStyle = 'Flat'
        $btn.FlatAppearance.BorderSize = 1
        $btn.Tag = $col
        $btn.Add_Click({
            $script:shortcutColor = $this.Tag
            try {
                $p = New-DesktopShortcut
                [System.Windows.Forms.MessageBox]::Show("Shortcut refreshed with new colour.`n$p", $script:appName, 'OK', 'Information') | Out-Null
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Could not update shortcut:`n$_", $script:appName, 'OK', 'Error') | Out-Null
            }
        })
        $grpColour.Controls.Add($btn)
        $swX += ($swSize + $gap)
        if ($swX -gt (420 - $swSize - 12)) { $swX = 12; $swY += ($swSize + $gap) }
    }

    $btnCustom = New-Object System.Windows.Forms.Button
    $btnCustom.Text = 'Custom colour...'
    $btnCustom.Location = '12,112'; $btnCustom.Size = '130,24'
    $btnCustom.Add_Click({
        $cd = New-Object System.Windows.Forms.ColorDialog
        $cd.FullOpen = $true
        $cd.Color = $script:shortcutColor
        if ($cd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $script:shortcutColor = $cd.Color
            try {
                $p = New-DesktopShortcut
                [System.Windows.Forms.MessageBox]::Show("Shortcut refreshed with custom colour.`n$p", $script:appName, 'OK', 'Information') | Out-Null
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Could not update shortcut:`n$_", $script:appName, 'OK', 'Error') | Out-Null
            }
        }
        $cd.Dispose()
    })
    $grpColour.Controls.Add($btnCustom)

    $btnRefresh = New-Object System.Windows.Forms.Button
    $btnRefresh.Text = 'Create / refresh desktop shortcut'
    $btnRefresh.Location = '152,112'; $btnRefresh.Size = '180,24'
    $btnRefresh.Add_Click({
        try {
            $p = New-DesktopShortcut
            [System.Windows.Forms.MessageBox]::Show("Desktop shortcut created/updated:`n$p", $script:appName, 'OK', 'Information') | Out-Null
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Could not create shortcut:`n$_", $script:appName, 'OK', 'Error') | Out-Null
        }
    })
    $grpColour.Controls.Add($btnRefresh)

    $btnRemove = New-Object System.Windows.Forms.Button
    $btnRemove.Text = 'Remove shortcut'
    $btnRemove.Location = '340,112'; $btnRemove.Size = '70,24'
    $btnRemove.Add_Click({
        try {
            Remove-DesktopShortcut
            [System.Windows.Forms.MessageBox]::Show('Desktop shortcut removed.', $script:appName, 'OK', 'Information') | Out-Null
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Could not remove shortcut:`n$_", $script:appName, 'OK', 'Error') | Out-Null
        }
    })
    $grpColour.Controls.Add($btnRemove)

    # --- Close button ---
    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = 'Close'
    $btnClose.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $btnClose.Location = '347,355'; $btnClose.Size = '85,28'
    $dlg.Controls.Add($btnClose)
    $dlg.AcceptButton = $btnClose

    $dlg.Add_Shown({ $dlg.Activate() })
    [void]$dlg.ShowDialog()
    $script:installPath = $txtPath.Text.Trim()
    Export-AppSettings
    $dlg.Dispose()
}

# ---------------------------------------------------------------------------
# Build main form
# ---------------------------------------------------------------------------
Import-AppSettings
[void](Get-DefaultIconPath)   # ensure default icon exists

$mainForm = New-Object System.Windows.Forms.Form
$mainForm.Text = $script:appName
$mainForm.Size = New-Object System.Drawing.Size(1000, 700)
$mainForm.StartPosition = 'CenterScreen'
$mainForm.Font = New-Object System.Drawing.Font('Segoe UI', 10)
# Build the form icon from a GDI+ handle (avoids any PNG-ICO parsing quirk).
$iconBmp = New-IconBitmap -Size 32 -BaseColor $script:shortcutColor
$mainForm.Icon = [System.Drawing.Icon]::FromHandle($iconBmp.GetHicon())
$mainForm.Add_FormClosing({
    if (-not (Confirm-SaveIfModified)) { $_.Cancel = $true }
})

# --- Menu strip ---
$menu = New-Object System.Windows.Forms.MenuStrip

$mFile = $menu.Items.Add('&File')
$miNew = $mFile.DropDownItems.Add('&New')
$miNew.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::N
$miNew.Add_Click({ New-Document })
$miOpen = $mFile.DropDownItems.Add('&Open...')
$miOpen.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::O
$miOpen.Add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = 'Documents (*.rtf;*.txt)|*.rtf;*.txt|Rich Text (*.rtf)|*.rtf|Plain Text (*.txt)|*.txt|All files (*.*)|*.*'
    if ($ofd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { Open-Document -Path $ofd.FileName }
    $ofd.Dispose()
})
$miSave = $mFile.DropDownItems.Add('&Save')
$miSave.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::S
$miSave.Add_Click({ Save-Document })
$miSaveAs = $mFile.DropDownItems.Add('Save &As...')
$miSaveAs.Add_Click({ Save-DocumentAs })
[void]$mFile.DropDownItems.Add('-')
$miSettings = $mFile.DropDownItems.Add('&Settings...')
$miSettings.Add_Click({ Show-SettingsDialog })
[void]$mFile.DropDownItems.Add('-')
$miExit = $mFile.DropDownItems.Add('E&xit')
$miExit.Add_Click({ $mainForm.Close() })

$mEdit = $menu.Items.Add('&Edit')
$miUndo = $mEdit.DropDownItems.Add('&Undo'); $miUndo.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::Z
$miUndo.Add_Click({ if ($rtb.CanUndo) { $rtb.Undo() } })
$miRedo = $mEdit.DropDownItems.Add('&Redo'); $miRedo.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::Y
$miRedo.Add_Click({ if ($rtb.CanRedo) { $rtb.Redo() } })
[void]$mEdit.DropDownItems.Add('-')
$miCut = $mEdit.DropDownItems.Add('Cu&t'); $miCut.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::X
$miCut.Add_Click({ $rtb.Cut() })
$miCopy = $mEdit.DropDownItems.Add('&Copy'); $miCopy.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::C
$miCopy.Add_Click({ $rtb.Copy() })
$miPaste = $mEdit.DropDownItems.Add('&Paste'); $miPaste.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::V
$miPaste.Add_Click({ $rtb.Paste() })
$miSelAll = $mEdit.DropDownItems.Add('Select &All'); $miSelAll.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::A
$miSelAll.Add_Click({ $rtb.SelectAll() })

$mFmt = $menu.Items.Add('F&ormat')
$miBold = $mFmt.DropDownItems.Add('&Bold'); $miBold.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::B
$miBold.Add_Click({ Toggle-Style -Style ([System.Drawing.FontStyle]::Bold) })
$miItalic = $mFmt.DropDownItems.Add('&Italic'); $miItalic.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::I
$miItalic.Add_Click({ Toggle-Style -Style ([System.Drawing.FontStyle]::Italic) })
$miUnder = $mFmt.DropDownItems.Add('&Underline'); $miUnder.ShortcutKeys = [System.Windows.Forms.Keys]::Control -bor [System.Windows.Forms.Keys]::U
$miUnder.Add_Click({ Toggle-Style -Style ([System.Drawing.FontStyle]::Underline) })
$miStrike = $mFmt.DropDownItems.Add('&Strikethrough')
$miStrike.Add_Click({ Toggle-Style -Style ([System.Drawing.FontStyle]::Strikeout) })
[void]$mFmt.DropDownItems.Add('-')
$miFont = $mFmt.DropDownItems.Add('&Font...')
$miFont.Add_Click({
    $fd = New-Object System.Windows.Forms.FontDialog
    $fd.Font = $rtb.SelectionFont
    $fd.Color = $rtb.SelectionColor
    $fd.ShowColor = $true
    if ($fd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        if ($fd.Font) { $rtb.SelectionFont = $fd.Font }
        $rtb.SelectionColor = $fd.Color
    }
    $fd.Dispose()
})
$miFore = $mFmt.DropDownItems.Add('&Text colour...')
$miFore.Add_Click({
    $cd = New-Object System.Windows.Forms.ColorDialog
    $cd.Color = $rtb.SelectionColor
    if ($cd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $rtb.SelectionColor = $cd.Color }
    $cd.Dispose()
})
$miHigh = $mFmt.DropDownItems.Add('&Highlight colour...')
$miHigh.Add_Click({
    $cd = New-Object System.Windows.Forms.ColorDialog
    $cd.Color = $rtb.SelectionBackColor
    if ($cd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $rtb.SelectionBackColor = $cd.Color }
    $cd.Dispose()
})
[void]$mFmt.DropDownItems.Add('-')
$miLeft = $mFmt.DropDownItems.Add('Align &Left'); $miLeft.Add_Click({ $rtb.SelectionAlignment = 'Left' })
$miCenter = $mFmt.DropDownItems.Add('Align &Center'); $miCenter.Add_Click({ $rtb.SelectionAlignment = 'Center' })
$miRight = $mFmt.DropDownItems.Add('Align &Right'); $miRight.Add_Click({ $rtb.SelectionAlignment = 'Right' })
[void]$mFmt.DropDownItems.Add('-')
$miBullet = $mFmt.DropDownItems.Add('&Bullets'); $miBullet.CheckOnClick = $true
$miBullet.Add_Click({ $rtb.SelectionBullet = -not $rtb.SelectionBullet })

$mHelp = $menu.Items.Add('&Help')
$miAbout = $mHelp.DropDownItems.Add('&About')
$miAbout.Add_Click({
    [System.Windows.Forms.MessageBox]::Show(
        "$($script:appName)`nSingle-file PowerShell rich-text editor.`nFile > Settings to install / create desktop shortcut / colour the shortcut icon.",
        "About $($script:appName)", 'OK', 'Information') | Out-Null
})

$mainForm.MainMenuStrip = $menu
$mainForm.Controls.Add($menu)

# --- Tool strip ---
$tool = New-Object System.Windows.Forms.ToolStrip
$tool.GripStyle = 'Hidden'

function Add-ToolButton {
    param([string]$Text, [scriptblock]$OnClick, [string]$ToolTip)
    $btn = New-Object System.Windows.Forms.ToolStripButton
    $btn.Text = $Text
    $btn.DisplayStyle = 'Text'
    $btn.ToolTipText = $ToolTip
    $btn.Add_Click($OnClick)
    $tool.Items.Add($btn) | Out-Null
}

Add-ToolButton 'New'  { New-Document } 'New document (Ctrl+N)'
Add-ToolButton 'Open' {
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = 'Documents (*.rtf;*.txt)|*.rtf;*.txt|All files (*.*)|*.*'
    if ($ofd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { Open-Document -Path $ofd.FileName }
    $ofd.Dispose()
} 'Open document (Ctrl+O)'
Add-ToolButton 'Save' { Save-Document } 'Save (Ctrl+S)'
$tool.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
Add-ToolButton 'B' { Toggle-Style -Style ([System.Drawing.FontStyle]::Bold) } 'Bold (Ctrl+B)'
Add-ToolButton 'I' { Toggle-Style -Style ([System.Drawing.FontStyle]::Italic) } 'Italic (Ctrl+I)'
Add-ToolButton 'U' { Toggle-Style -Style ([System.Drawing.FontStyle]::Underline) } 'Underline (Ctrl+U)'
$tool.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
Add-ToolButton 'A▼' {
    $cd = New-Object System.Windows.Forms.ColorDialog
    if ($cd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $rtb.SelectionColor = $cd.Color }
    $cd.Dispose()
} 'Text colour'
Add-ToolButton '▨' {
    $cd = New-Object System.Windows.Forms.ColorDialog
    if ($cd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $rtb.SelectionBackColor = $cd.Color }
    $cd.Dispose()
} 'Highlight colour'
$tool.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
Add-ToolButton '⇤' { $rtb.SelectionAlignment = 'Left' } 'Align left'
Add-ToolButton '☰' { $rtb.SelectionAlignment = 'Center' } 'Align center'
Add-ToolButton '⇥' { $rtb.SelectionAlignment = 'Right' } 'Align right'
$tool.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
Add-ToolButton '• List' { $rtb.SelectionBullet = -not $rtb.SelectionBullet } 'Toggle bullets'

$mainForm.Controls.Add($tool)

# --- Rich text box ---
$rtb = New-Object System.Windows.Forms.RichTextBox
$rtb.Dock = 'Fill'
$rtb.AcceptsTab = $true
$rtb.DetectUrls = $true
$rtb.EnableAutoDragDrop = $true
$rtb.HideSelection = $false
$rtb.Font = New-Object System.Drawing.Font('Segoe UI', 11)
$mainForm.Controls.Add($rtb)
# Docking layout: Fill control must be at the back (laid out last),
# menu at the front so it sits above the toolbar on the top edge.
$rtb.SendToBack()
$menu.BringToFront()

# --- Status strip ---
$status = New-Object System.Windows.Forms.StatusStrip
$lblPos  = New-Object System.Windows.Forms.ToolStripStatusLabel
$lblPos.Text = 'Ln 1, Col 1'
$lblPos.Spring = $false
$lblWords = New-Object System.Windows.Forms.ToolStripStatusLabel
$lblWords.Text = 'Words: 0'
$lblWords.Spring = $true
$lblWords.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$status.Items.Add($lblPos) | Out-Null
$status.Items.Add($lblWords) | Out-Null
$mainForm.Controls.Add($status)

# --- Behaviour ---
function Toggle-Style {
    param([System.Drawing.FontStyle]$Style)
    if ($null -eq $rtb.SelectionFont) { return }
    if ($rtb.SelectionFont.Style -band $Style) {
        $rtb.SelectionFont = New-Object System.Drawing.Font($rtb.SelectionFont, ($rtb.SelectionFont.Style -bxor $Style))
    } else {
        $rtb.SelectionFont = New-Object System.Drawing.Font($rtb.SelectionFont, ($rtb.SelectionFont.Style -bor $Style))
    }
}

function Update-Status {
    $idx = $rtb.SelectionStart
    $line = $rtb.GetLineFromCharIndex($idx) + 1
    $first = $rtb.GetFirstCharIndexOfCurrentLine()
    $col = $idx - $first + 1
    $lblPos.Text = "Ln $line, Col $col"
    $text = $rtb.Text
    $words = 0
    if ($text.Trim().Length -gt 0) { $words = ([regex]::Matches($text, '\S+')).Count }
    $lblWords.Text = "Words: $words   Chars: $($text.Length)"
}

$rtb.Add_TextChanged({
    $script:modified = $true
    Set-Title
    Update-Status
})
$rtb.Add_SelectionChanged({ Update-Status })

Set-Title
Update-Status

# Open file passed on command line, if any
if ($File -and (Test-Path -LiteralPath $File)) {
    $script:currentFile = (Resolve-Path -LiteralPath $File).Path
    try {
        $rtb.LoadFile($script:currentFile, (Get-StreamType $script:currentFile))
        $script:modified = $false
    } catch {
        $rtb.Text = Get-Content -LiteralPath $script:currentFile -Raw -Encoding UTF8
        $script:modified = $false
    }
    Set-Title
}

[void]$mainForm.ShowDialog()
