#Requires -Version 5.1
<#
.SYNOPSIS
    Uninstaller for PS Rich Text Editor. Removes shortcuts, the Add/Remove
    Programs entry, and the install folder (including this file).
#>
$ErrorActionPreference = "SilentlyContinue"

$appName    = "PS Rich Text Editor"
$appId      = "PSRichTextEditor"
$installDir = Join-Path $env:LOCALAPPDATA "Programs\$appId"
$startMenu  = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\$appName"
$desktopLnk = Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) "$appName.lnk"

Remove-Item -LiteralPath $desktopLnk -Force
Remove-Item -LiteralPath $startMenu -Recurse -Force
Remove-Item -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$appId" -Force
Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'PSRichTextEditor') -Recurse -Force  # app data/settings

# Remove the install folder (and this script inside it). PowerShell has already
# loaded the whole file, so deleting it mid-run is safe.
if (Test-Path -LiteralPath $installDir) {
    Remove-Item -LiteralPath $installDir -Recurse -Force
}

Write-Host "$appName was uninstalled." -ForegroundColor Green
Start-Sleep -Seconds 2
